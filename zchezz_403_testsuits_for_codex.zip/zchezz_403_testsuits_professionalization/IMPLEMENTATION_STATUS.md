# Implementation Status

## Implemented in this overlay

- professionalization execution plan;
- canonical numeric engine/path resolver;
- shared UCI subprocess driver;
- canonical test runner with smoke/full/web/regression/release profiles;
- explicit v403/v402 candidate-baseline wiring;
- repository-contract tests;
- agent-rule synchronization tests;
- documentation truth tests;
- deterministic golden-contract scaffold;
- fast repository checker;
- NNU4 structural/checksum checker;
- EPD/FEN structural checker;
- release-manifest generator;
- native C board/hash/occupancy/NNUE invariant harness;
- build patch for v403 default, overridable architecture flags, debug, ASan+UBSan and native invariant targets;
- GitHub Actions deterministic/native/sanitizer/WASM jobs;
- sanitizer runtime UCI smoke, not build-only validation;
- manually triggered regression-workflow policy;
- focused architecture, build, testing, regression, NNUE, Syzygy, WASM, release and artifact documentation;
- concise synchronized AGENTS/CLAUDE replacements preserving the v403 critical invariants and training-data conventions;
- third-party provenance audit scaffold;
- development dependency metadata;
- conservative migration of known stale v4.00-era test/tournament defaults when applying the overlay;
- nested `__pycache__`/`.pyc` exclusion in the applicator.

## Validation completed in the originating session

See `TEST_REPORT.md`.

Key results:

- synthetic full overlay tests: 25 passed, 1 expected skip;
- focused quality-tool tests: 12 passed;
- applicator integration tests: 21 passed;
- C invariant harness syntax/API-surface compilation: PASS;
- explicit `ENGINE=v403 native` compiler-command equivalence before/after Makefile refactor: PASS.

## Requires execution in a real checkout

- native compile against the complete v403 tree;
- real C invariant harness;
- perft and extended UCI suites;
- committed NNUE binary inspection;
- sanitizer runtime;
- WASM + Playwright;
- H2H/SPRT where a change can affect strength;
- resolution of the current `tbprobe.c`/Fathom source-location question discovered during read-only inspection;
- complete license/provenance audit.

## GitHub write limitation

The connected GitHub app in ChatGPT is read-only by product design. The app-specific ChatGPT permission is already set to allow all available actions, but that does not grant repository write scopes. OpenAI documentation directs code editing/pushing through Codex.
