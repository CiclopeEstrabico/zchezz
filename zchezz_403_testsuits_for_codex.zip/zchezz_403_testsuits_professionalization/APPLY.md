# Apply to `403_testsuits`

This overlay was prepared against branch `403_testsuits` at base commit:

```text
56b2076f2537144013e39bdff1f8e116c03cfe39
```

It contains new/replacement files plus minimal patches for existing files.

On a clean checkout of `403_testsuits`:

```bash
# Copy every overlay file except APPLY.md, BASE_*.txt and patches/ into the repository,
# preserving relative paths.
git apply patches/engine-build-Makefile.patch
git apply patches/gitignore.patch

python tools/check_repo.py
python -m pytest tests/test_agent_instructions.py tests/test_repository_contracts.py tests/test_documentation.py -q
make -C engine/build ENGINE=v403 test-c
python tests/run_tests.py smoke --version v403
```

The GitHub connector in the originating ChatGPT session had read access but returned HTTP 403 for every write action, including writes to this user-created branch. Therefore the overlay could not be committed remotely from that session.
