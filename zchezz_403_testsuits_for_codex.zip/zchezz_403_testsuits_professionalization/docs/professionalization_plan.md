# Zchezz Repository Professionalization Plan

## Goal

Transform Zchezz into a reproducible engineering repository with explicit quality gates, traceable releases, deterministic regression tests, statistical strength testing, tested documentation, and consistent agent rules.

This work starts from branch `403_testsuits`, based on commit `56b2076f2537144013e39bdff1f8e116c03cfe39`. Infrastructure changes must not alter chess behavior unless a later task explicitly requires such a change.

## Principles

1. Build the safety net before reorganizing engine source history.
2. Separate correctness, deterministic regression, performance, and playing-strength evidence.
3. Keep local and CI commands identical.
4. Make repository conventions executable through tests.
5. Keep generated artifacts explicit and traceable.
6. Preserve released engine folders until a separate source-layout migration is approved.
7. Reproduce a logic bug before fixing it. Add a regression test before the fix when practical.
8. Treat documentation that describes code as part of the tested product.

## Execution phases

### Phase 0 — Baseline

Record the base Git SHA, engine version, compiler settings, NNUE identity, perft result, UCI result, representative benchmark result, WASM build state, and browser test state. Store machine-readable metadata under `tests/data/baseline/`.

### Phase 1 — Repository path and version layer

Create one shared module that owns repository-root discovery, numeric engine-version parsing, engine artifact paths, build paths, tablebase/opening paths, and artifact directories. New code must not implement its own engine discovery.

### Phase 2 — Unified test runner

Create `tests/run_tests.py` with `smoke`, `full`, `web`, `regression`, `release`, and `--list` profiles. The runner writes text and JSON reports under `artifacts/tests/` and returns nonzero on required failures.

### Phase 3 — Test taxonomy

Classify evidence as correctness, protocol, engine invariants, deterministic golden regression, statistical regression, performance, browser/WASM, or repository contracts. A golden test says that behavior changed. An invariant test says that behavior is invalid.

### Phase 4 — C-level invariants

Add a native harness for make/unmake restoration, incremental versus recomputed Zobrist hash, occupancy/bitboard consistency, NNUE incremental versus full rebuild, draw-state behavior, and other public invariants.

### Phase 5 — Deterministic golden regression

Create explicit fixtures for stable deterministic behavior. Golden updates require an explicit tool. A normal test run never rewrites the record.

### Phase 6 — UCI framework

Create one reusable subprocess driver. Cover handshake, readiness, new game, position commands, search modes, MultiPV, Threads, Hash, NNUE, book, Syzygy, repeated start/stop cycles, clean exit, and valid `bestmove` syntax. Optional external resources produce explicit skips.

### Phase 7 — WASM/browser quality gate

Run Playwright headlessly by default. Capture page errors and console errors. Prefer state-based waits to arbitrary sleeps. Test page load, WASM initialization, game play, analysis, MultiPV, clocks, reset behavior, promotion, piece sets, and offline standalone operation.

### Phase 8 — Build configurations and sanitizers

Expose release/native, debug, ASan+UBSan, native invariant tests, WASM, bundle, selfplay, arena, and GA tuner targets. Add ThreadSanitizer separately because Lazy SMP intentionally shares selected structures.

### Phase 9 — Continuous integration

Run repository contracts, Python/tool checks, native GCC/Clang builds where practical, deterministic smoke tests, sanitizer smoke tests, WASM builds, and browser tests. Do not make long Elo/SPRT runs mandatory on noisy shared runners.

### Phase 10 — Statistical strength regression

Use SPRT for promotion decisions where practical. Every run records both Git SHAs, engine labels, NNUE hashes, openings, seed, color pairing, time control, thread/hash settings, W/D/L, Elo uncertainty or SPRT state, crashes, time losses, and PGN path.

### Phase 11 — Regression tiers

- Tier A: every engine-source change — build, contracts, C invariants, perft, UCI smoke, deterministic golden checks.
- Tier B: search/evaluation — Tier A plus suites, deterministic benchmark, quick H2H.
- Tier C: NNUE/TB/threading/time-management — Tier B plus feature-specific checks.
- Tier D: release candidate — full deterministic suite, sanitizers, browser/WASM, and statistical promotion gate.

Documentation-only changes do not require hundreds of chess games.

### Phase 12 — Agent rules

Keep `AGENTS.md` and `CLAUDE.md` equivalent in working rules. Keep `.agents/skills/writing-rules/SKILL.md` and `.claude/skills/writing-rules/SKILL.md` identical. Agent files contain working rules and critical invariants. Long architecture explanations live under `docs/`.

### Phase 13 — Repository contracts

Automated checks cover objective facts: required files, documented paths, stale hard-coded versions, hard-coded local roots, agent-rule synchronization, writing-skill synchronization, piece-set completeness, and basic test-data sanity.

### Phase 14 — Documentation structure

Maintain focused files for architecture, build, testing, regression testing, engine contracts, repository layout, WASM, NNUE, Syzygy, generated artifacts, and releases.

### Phase 15 — Repository organization

Target top level:

```text
.github/
.agents/
.claude/
docs/
engine/
openings/
tests/
tools/
train/
utils/
artifacts/        # generated, ignored
README.md
AGENTS.md
CLAUDE.md
LICENSE
THIRD_PARTY_NOTICES.md
pyproject.toml
.gitignore
```

Do not migrate versioned engine folders yet. Centralize their interpretation first.

### Phase 16 — Provenance and generated artifacts

Document external suites/assets and classify generated files as generated-and-committed, generated-and-ignored, release artifact, or test artifact. Prefer generated output under `artifacts/` or `dist/`.

### Phase 17 — Release manifest

Each release produces a machine-readable manifest with version, Git SHA, compiler, flags, NNUE SHA-256, book SHA-256 when applicable, deterministic test status, sanitizer status, WASM/browser status, and regression evidence.

### Phase 18 — Optional source-layout migration

Only after the safety net is stable, evaluate replacing `engine/c/zchezz_vXXX/` source duplication with one active source tree plus Git tags/releases.

## Initial implementation order

1. Shared repository paths/version module.
2. Shared UCI helper.
3. Unified test runner.
4. Repository-contract tests and fast checker.
5. Agent-instruction synchronization test.
6. Documentation truth tests.
7. Build/debug/sanitizer targets.
8. CI.
9. Focused documentation.
10. Native C invariants.
11. Deterministic golden snapshot scaffold.
12. Browser/WASM hardening.
13. Statistical regression manifests.
14. Provenance and generated-artifact audit.
15. Source-layout review only after the gates are stable.

## Definition of done

The program is complete when active tools do not depend on stale hard-coded versions, engine discovery has one implementation, one canonical test runner exists, deterministic and native invariants exist, sanitizer and browser/WASM checks are automated, CI runs deterministic gates, agent/documentation contracts cannot drift silently, regression runs are reproducible, generated artifacts have a policy, releases have machine-readable manifests, and infrastructure changes do not silently alter engine behavior.
