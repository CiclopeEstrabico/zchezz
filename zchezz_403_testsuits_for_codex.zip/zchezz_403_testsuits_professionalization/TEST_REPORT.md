# Validation Report

## Scope

This report covers the professionalization overlay prepared for branch `403_testsuits`, based on commit `56b2076f2537144013e39bdff1f8e116c03cfe39`.

## What was verified in this session

### Overlay/package validation

- Python syntax/encoding: PASS for all overlay Python files.
- JSON parsing: PASS for all overlay JSON files.
- `AGENTS.md` / `CLAUDE.md` body synchronization: PASS.
- Synthetic repository pre-flight: PASS.
- Overlay pytest suite in a synthetic repository: 25 passed, 1 skipped.
  - The skipped test was the built-engine UCI golden check because the synthetic repository deliberately had no engine executable.
- Focused overlay/tool tests: 12 passed.
- Apply-script integration test on a synthetic `403_testsuits` Git repository: 21 passed.
- Apply script preserves nested `__pycache__` / `.pyc` cleanliness: PASS.
- C invariant harness syntax/API-surface compilation with `gcc -Wall -Wextra -Wpedantic -Werror -fsyntax-only`: PASS.
- Production `native` command equivalence for explicit `ENGINE=v403`: PASS. The old and new generated gcc commands were identical; `ARCH_FLAGS` only factors the existing `-mavxvnni -mavx2` flags into an overridable variable.

### Defects found and fixed during validation

1. `regression` profile originally inherited the old v401/v400 defaults from `run_tournament_quick.py`.
   - Fixed: candidate and baseline are now explicit; v403 defaults to v402.
2. `smoke` did not build the candidate before black-box perft/UCI tests.
   - Fixed: native build is now an explicit required smoke step.
3. Sanitizer workflow only compiled the engine.
   - Fixed: sanitized binary is now exercised through UCI smoke tests.
4. `test_test_runner.py` imported a dataclass module without registering it in `sys.modules` under Python 3.13.
   - Fixed.
5. Repository hard-coded-root detectors matched their own source text.
   - Fixed.
6. Overlay copy filter could copy nested `__pycache__` directories generated during validation.
   - Fixed and caches removed from the package.
7. Legacy default presets still pointed at v4.00-era engines.
   - Apply script now updates the known v403 worktree defaults conservatively when the original text still matches.
8. General tournament preset had a path/label mismatch (`v402` path labeled `v401`).
   - Apply script fixes the label when that exact legacy text is present.

## Source-behavior preservation

The overlay does not contain replacements for any file under `engine/c/zchezz_v403/`.
The only new file under `engine/c/` is `engine/c/tests/test_engine_invariants.c`.

The Makefile production build flags remain unchanged by default. The only intended production-facing change is that the shared Makefile default engine changes from v402 to v403 for this experimental branch. Explicit `ENGINE=v403 native` produces the same compiler command as before the Makefile refactor.

Therefore the professionalization overlay, as packaged, does not deliberately alter engine search, evaluation, board, NNUE, Syzygy, book, or UCI source logic.

## What could not be executed here

A complete real-runtime validation requires a full checkout of the repository. That was not available in this session for two independent reasons:

1. The ChatGPT GitHub connector is read-only and returned HTTP 403 for all write attempts.
2. The shell/container environment could not resolve `github.com`, so a `git clone` of `403_testsuits` could not be performed.

Because of that, these real-repository runtime gates were not executed in this session:

- native v403 compile against the complete repository;
- native C invariant harness linked against the real v403 sources;
- real v403 perft suite;
- real v403 extended UCI suite;
- real NNU4 parser check against the committed weight bytes;
- ASan/UBSan runtime on the real engine;
- WASM compilation;
- Playwright browser end-to-end tests;
- H2H/SPRT strength regression.

These checks are wired into the overlay/CI and must be run in Codex or GitHub Actions after the overlay is applied.

## Important repository issue discovered by read-only inspection

The shared `engine/build/Makefile` currently names `$(EDIR)/tbprobe.c`, while a direct lookup of `engine/c/zchezz_v403/tbprobe.c` returned 404. `syzygy.c` includes `tbprobe.h`, so the real native build should be used to establish where the Fathom source is expected to come from before treating the Makefile default switch to v403 as validated. This is exactly the kind of repository-contract issue the new build/CI gate is intended to catch.

## Acceptance condition

Do not call the branch fully validated until the following command succeeds in a real checkout:

```bash
python tests/run_tests.py release --version v403 --baseline v402 --keep-going
```

Then run the explicit statistical promotion workflow only for changes that can affect playing strength.
