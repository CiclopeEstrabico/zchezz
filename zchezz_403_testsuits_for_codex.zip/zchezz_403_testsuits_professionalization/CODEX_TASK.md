# Codex task — Zchezz professionalization

Target repository: `gitzambrano/zchezz`
Target branch: `403_testsuits`
Base commit: `56b2076f2537144013e39bdff1f8e116c03cfe39`

## Goal

Apply this professionalization package to the target branch, then validate the real repository end to end without changing chess-engine behavior unless a failing test proves that a repository/build defect must be fixed.

## Required execution

1. Verify that the checkout is on `403_testsuits` and that the expected base history is present.
2. Read `APPLY.md`, `IMPLEMENTATION_STATUS.md`, `TEST_REPORT.md`, and `docs/professionalization_plan.md` before editing.
3. Run `apply_professionalization.py` from this package against the repository checkout.
4. Inspect every resulting diff before proceeding.
5. Resolve any integration problem against the real v403 tree, especially the current `tbprobe.c` / Fathom build-path inconsistency noted in `TEST_REPORT.md`.
6. Do not modify released engine sources merely to satisfy infrastructure tests. Preserve `engine/c/zchezz_v403/*.c` and `*.h` unless a real defect is demonstrated and explicitly documented.
7. Run the complete validation stack on the real checkout:

```bash
python tests/run_tests.py smoke --version v403 --baseline v402 --keep-going
python tests/run_tests.py full --version v403 --baseline v402 --keep-going
python tests/run_tests.py web --version v403 --baseline v402 --keep-going
python tests/run_tests.py release --version v403 --baseline v402 --keep-going
```

8. Also run the native C invariant target and sanitizers directly if the runner cannot reach them because of platform/toolchain limitations.
9. Run the existing legacy tests that are not yet represented in the unified runner and compare their behavior with the baseline.
10. For any failure, diagnose it, fix the infrastructure or real repository defect, and rerun the affected tests plus the release profile.
11. Verify that v403 engine source hashes did not change unintentionally.
12. Produce a concise final report containing:
   - files changed;
   - tests executed;
   - exact pass/fail/skip counts;
   - any platform-limited tests;
   - any discovered repository defects;
   - whether production engine behavior/source changed;
   - remaining risks.
13. Commit the completed work to `403_testsuits` only after the real test suite is green to the extent supported by the available environment.

Do not claim that a test passed unless its command was actually executed and its result was inspected.
