# CLAUDE.md

## Scope

This file contains working rules and critical invariants. Architecture, build details, test design, and release process live under `docs/`.

## Baseline

The professionalization worktree is branch `403_testsuits`, based on the v403 LC0-training line. Treat `engine/c/zchezz_v403/` as the active experimental core for this branch. Released engine folders remain immutable unless a task explicitly creates a new version.

## Core workflow

1. Reproduce a logic defect before fixing it when practical.
2. Add a regression test for logic fixes. Confirm that it fails before the fix when practical.
3. Run the smallest focused test during development.
4. Run the appropriate profile from `tests/run_tests.py` before reporting completion.
5. Update documentation in the same change when behavior or a public workflow changes.
6. Inspect the actual diff and test output. A subagent summary is not evidence.
7. Do not run long Elo tests for documentation-only or repository-only changes.

## Test tiers

- Tier A: build, repository contracts, C invariants, perft, UCI smoke, deterministic golden contracts.
- Tier B: Tier A plus suites, deterministic benchmark, quick H2H for search/evaluation changes.
- Tier C: Tier B plus feature-specific NNUE/TB/threading/time-management checks.
- Tier D: release profile plus statistical promotion evidence.

Use `docs/testing.md` and `docs/regression-testing.md` for the detailed policy.

## Version and path rules

Use `utils/repo_paths.py` for new Python path/version discovery. Do not hard-code `C:\\Zchezz`. Do not implement another lexical `glob(...)[-1]` version resolver.

`tests/` and `train/` are flat and version-less. Do not create version subdirectories inside them.

## Tool configuration

Every command-line tool must have one documented configuration/default source. A CLI parser must reference those defaults rather than duplicate literals. Existing `utils/cliconf.py` conventions remain valid.

## Native and Python harnesses

Native C tools are faster paths, not reduced replacements. Preserve important capabilities such as paired openings and standard PGN output when a native path overlaps an existing Python harness.

Use native arena/SPRT for version promotion. Keep calibrated external-anchor tournaments in the Python tournament harness unless a deliberate architecture change says otherwise.

## Training-data convention

Use exactly these semantic names in training data:

- `result`: real game outcome, White-relative, 0.0/0.5/1.0;
- `cp`: centipawn evaluation, White-relative;
- `wdl`: `sigmoid(cp / 320)`, White-relative.

`wdl` is derived from `cp`; it is not a game outcome. The training target is computed at training time:

```text
target = lambda * result_prob + (1 - lambda) * wdl
```

Do not bake the blend into the dataset.

## Critical engine invariants

- NNUE concat order is always `[stm, opp]`.
- A king move that crosses its own perspective's king-bucket boundary invalidates that perspective until lazy rebuild.
- TT probe occurs before TB probe under the current search design.
- Selfplay shares one `TTable` between the two colors of a game and physically clears it between games.
- Arena isolates a `TTable` per player.
- Lazy SMP helpers intentionally share the main thread's `TTable` pointer.
- Only the intended main-thread path advances shared TT generation.
- Mailbox, bitboards, cached occupancy, and Zobrist hash must remain mutually consistent.
- Incremental NNUE must equal a full rebuild for the same position and network.

See `docs/engine-contracts.md` for executable contract identifiers.

## C conventions

- C11; no C++ features.
- Preserve the square convention `a8=0`, `h1=63`.
- Preserve piece encoding `COL_W=8`, `COL_B=16`, type 1-6 for P/N/B/R/Q/K.
- Make ownership of mutable shared state explicit.
- Comments explain invariants, assumptions, ownership, units, score conventions, and non-obvious algorithmic reasons. Do not narrate obvious syntax.

## WASM

The WASM target is single-threaded. It excludes file-based tablebases and opening-book I/O. Browser changes must pass the `web` profile before release.

## Writing

Write repository prose in concise formal technical English. Follow `.agents/skills/writing-rules/SKILL.md`. The mirror at `.claude/skills/writing-rules/SKILL.md` must remain byte-identical.

Use the same term for the same concept. Prefer active voice. State measurable behavior. Avoid marketing language and vague superlatives.

## Documentation

Durable information belongs under `docs/`. Agent files must not become a second architecture manual. Objective documentation facts are tested by `tests/test_documentation.py`.

## Completion rule

Do not report a change as complete while a required test fails, an implementation is partial without being identified as partial, or generated/release evidence refers to a different Git SHA than the code under review.
