#!/usr/bin/env python3
"""Apply this overlay to a clean checkout of branch 403_testsuits.

The script refuses a different branch unless --force is given. It copies the
new/replacement files and performs the two small edits that are represented as
patches in this package.
"""
from __future__ import annotations

import argparse
import shutil
import subprocess
from pathlib import Path

OVERLAY = Path(__file__).resolve().parent
SKIP_TOP = {"APPLY.md", "BASE_BRANCH.txt", "BASE_COMMIT.txt", "IMPLEMENTATION_STATUS.md", "apply_professionalization.py"}
SKIP_DIRS = {"patches", "__pycache__"}


def git_text(repo: Path, *args: str) -> str:
    return subprocess.check_output(["git", *args], cwd=repo, text=True).strip()


def replace_once(path: Path, old: str, new: str) -> None:
    text = path.read_text(encoding="utf-8")
    if new in text:
        return
    if old not in text:
        raise RuntimeError(f"cannot find expected text in {path}: {old!r}")
    path.write_text(text.replace(old, new, 1), encoding="utf-8")


def replace_if_present(path: Path, old: str, new: str) -> bool:
    """Replace one known legacy default when the file and text still match.

    Returns True when a replacement was made. Missing files or already-modern
    content are left unchanged so the overlay remains safe on later rebases.
    """
    if not path.is_file():
        return False
    text = path.read_text(encoding="utf-8")
    if old not in text:
        return False
    path.write_text(text.replace(old, new, 1), encoding="utf-8")
    return True


def patch_legacy_tool_defaults(repo: Path) -> None:
    """Update stale v4.00-era defaults without changing tool behavior.

    Canonical scripted runs pass explicit candidate/baseline values. These
    edits make a bare developer invocation agree with the active v403 worktree.
    """
    replace_if_present(repo / "tests" / "test_perft.py",
        'VERSION    = "v400"', 'VERSION    = "v403"')
    replace_if_present(repo / "tests" / "bench_nps.py",
        'HEAD_VERSION = "v400"', 'HEAD_VERSION = "v403"')
    replace_if_present(repo / "tests" / "bench_nps.py",
        'BASE_VERSION = "v314"', 'BASE_VERSION = "v402"')

    quick = repo / "tests" / "run_tournament_quick.py"
    for old, new in (
        (r'"path":     r"engine\c\zchezz_v401\zchezz.exe"', r'"path":     r"engine\c\zchezz_v403\zchezz.exe"'),
        ('"label":    "v401-1T"', '"label":    "v403-1T"'),
        (r'"path":     r"engine\c\zchezz_v400\zchezz.exe"', r'"path":     r"engine\c\zchezz_v402\zchezz.exe"'),
        ('"label":    "v400-1T"', '"label":    "v402-1T"'),
        ('GAMES_SELF_PLAY      = 500', 'GAMES_SELF_PLAY      = 100'),
        ('REPORT_LOOPS         = 200', 'REPORT_LOOPS         = 100'),
        ('Default: v4.00 (engine under test) vs v3.14 (previous stable baseline),',
         'Default: v4.03 (engine under test) vs v4.02 (previous stable baseline),'),
    ):
        replace_if_present(quick, old, new)

    # Fix a path/label mismatch in the general tournament preset.
    tournament = repo / "tests" / "run_tournament.py"
    replace_if_present(tournament, '"label":    "Zchezz-v401"', '"label":    "Zchezz-v402"')


def append_gitignore(repo: Path) -> None:
    path = repo / ".gitignore"
    text = path.read_text(encoding="utf-8") if path.exists() else ""
    block = """\n# Professionalization artifacts\nartifacts/\ndist/\nengine/c/zchezz_v*/zchezz_debug.exe\nengine/c/zchezz_v*/zchezz_sanitize.exe\nengine/build/test_engine_invariants.exe\n"""
    if "# Professionalization artifacts" not in text:
        path.write_text(text.rstrip() + block, encoding="utf-8")


def patch_makefile(repo: Path) -> None:
    path = repo / "engine" / "build" / "Makefile"
    replace_once(path,
        "ENGINE  ?= v402        # engine/c/zchezz_$(ENGINE)/ — default = newest version",
        "ENGINE  ?= v403        # engine/c/zchezz_$(ENGINE)/ — active experimental default")
    text = path.read_text(encoding="utf-8")
    if "ARCH_FLAGS ?=" not in text:
        text = text.replace(
            "CC      = gcc\nCFLAGS  = -O3 -ffast-math -D_GNU_SOURCE -std=c11 -mavxvnni -mavx2 -I$(EDIR)",
            "CC      = gcc\n# Override ARCH_FLAGS in CI or on older CPUs. Default preserves production behavior.\nARCH_FLAGS ?= -mavxvnni -mavx2\nCFLAGS  = -O3 -ffast-math -D_GNU_SOURCE -std=c11 $(ARCH_FLAGS) -I$(EDIR)",
        )
    text = text.replace(".PHONY: native clean wasm bundle selfplay arena ga_tune",
                        ".PHONY: native debug sanitize test-c clean wasm bundle selfplay arena ga_tune")
    marker = "$(TARGET): $(SRCS)\n\t$(CC) $(CFLAGS) $(WARNS) -o $@ $^ $(LDFLAGS)\n"
    addition = r'''

# Developer build: broad warnings and debug symbols. Warnings are visible but
# are not globally promoted to errors until the historical code is clean.
debug: $(SRCS)
	$(CC) -O0 -g3 -D_GNU_SOURCE -std=c11 -I$(EDIR) \
		-Wall -Wextra -Wpedantic -Wshadow \
		-o $(EDIR)/zchezz_debug.exe $(SRCS) -lm -pthread

# Dynamic sanitizer build. Do not use the normal static LDFLAGS here.
sanitize: $(SRCS)
	$(CC) -O1 -g3 -fno-omit-frame-pointer -fsanitize=address,undefined \
		-D_GNU_SOURCE -std=c11 -I$(EDIR) \
		-o $(EDIR)/zchezz_sanitize.exe $(SRCS) -lm -pthread -fsanitize=address,undefined

# Native invariant harness.
test-c: ../c/tests/test_engine_invariants.c $(EDIR)/board.c $(EDIR)/nnue.c
	$(CC) -O2 -g -D_GNU_SOURCE -std=c11 -I$(EDIR) \
		-o test_engine_invariants.exe ../c/tests/test_engine_invariants.c \
		$(EDIR)/board.c $(EDIR)/nnue.c -lm
	./test_engine_invariants.exe $(EDIR)/nnue_weights.bin
'''
    if "test-c: ../c/tests/test_engine_invariants.c" not in text:
        if marker not in text:
            raise RuntimeError("Makefile native target changed; apply the patch manually")
        text = text.replace(marker, marker + addition, 1)
    old_clean = "\trm -f $(TARGET) arena.exe selfplay.exe ga_tune.exe *.o $(EDIR)/zchezz_wasm.js $(EDIR)/zchezz_wasm.wasm $(EDIR)/zchezz_bundle.html"
    new_clean = "\trm -f $(TARGET) $(EDIR)/zchezz_debug.exe $(EDIR)/zchezz_sanitize.exe test_engine_invariants.exe arena.exe selfplay.exe ga_tune.exe *.o $(EDIR)/zchezz_wasm.js $(EDIR)/zchezz_wasm.wasm $(EDIR)/zchezz_bundle.html"
    text = text.replace(old_clean, new_clean)
    path.write_text(text, encoding="utf-8")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("repo", type=Path, help="path to a checkout of 403_testsuits")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    repo = args.repo.resolve()
    branch = git_text(repo, "rev-parse", "--abbrev-ref", "HEAD")
    if branch != "403_testsuits" and not args.force:
        raise SystemExit(f"refusing branch {branch!r}; expected '403_testsuits' (use --force to override)")

    for source in OVERLAY.rglob("*"):
        if not source.is_file():
            continue
        rel = source.relative_to(OVERLAY)
        if any(part in SKIP_DIRS for part in rel.parts) or (len(rel.parts) == 1 and rel.name in SKIP_TOP):
            continue
        # Infrastructure overlays must never overwrite a versioned engine core.
        if len(rel.parts) >= 3 and rel.parts[0:2] == ("engine", "c") and rel.parts[2].startswith("zchezz_v"):
            raise RuntimeError(f"overlay attempts to modify versioned engine core: {rel}")
        target = repo / rel
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)

    patch_legacy_tool_defaults(repo)
    patch_makefile(repo)
    append_gitignore(repo)
    print("Applied professionalization overlay.")
    print("Next: python tools/check_repo.py")
    print("Then: python tests/run_tests.py smoke --version v403")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
